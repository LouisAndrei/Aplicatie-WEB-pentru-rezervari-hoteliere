<header class="header">

   <section class="flex">

      <a href="dashboard.php" class="logo">Admin</a>

      <nav class="navbar">
         <a href="dashboard.php">acasa</a>
         <a href="bookings.php">rezervari</a>
         <a href="admins.php">admini</a>
         <a href="messages.php">mesaje</a>
         <a href="register.php">register</a>
         <a href="login.php">login</a>
         <a href="../components/admin_logout.php" onclick="return confirm('logout?');">logout</a>
      </nav>

      <div id="menu-btn" class="fas fa-bars"></div>

   </section>

</header>