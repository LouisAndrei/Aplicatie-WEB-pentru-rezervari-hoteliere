<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:0773784840"><i class="fas fa-phone"></i> 0773784840</a>
         <a href="mailto:ripeanu.louis.j9w@student.ucv.ro"><i class="fas fa-envelope"></i> ripeanu.louis.j9w@student.ucv.ro</a>
         <a href="#"><i class="fas fa-map-marker-alt"></i> Craiova, Dolj, Romania - 200259</a>
      </div>

      <div class="box">
         <a href="#home">acasa</a>
         <a href="#about">despre</a>
         <a href="bookings.php">rezervarile mele</a>
         <a href="#reservation">rezervari</a>
         <a href="#gallery">galerie</a>
         <a href="#contact">contact</a>
         <a href="#reviews">review-uri</a>
      </div>

      <div class="box">
         <a href="#">facebook <i class="fab fa-facebook-f"></i></a>
         <a href="#">twitter <i class="fab fa-twitter"></i></a>
         <a href="#">instagram <i class="fab fa-instagram"></i></a>
         <a href="#">linkedin <i class="fab fa-linkedin"></i></a>
         <a href="#">youtube <i class="fab fa-youtube"></i></a>
      </div>

   </div>

   
</section>

