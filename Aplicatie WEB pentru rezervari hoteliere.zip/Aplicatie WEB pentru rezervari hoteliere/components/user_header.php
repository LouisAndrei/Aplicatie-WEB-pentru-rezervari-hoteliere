<section class="header">

   <div class="flex">
      <a href="#home" class="logo">Hotel</a>
      <a href="#availability" class="btn">verifică disponibilitatea</a>
      <a href="login.php"><div id="menu-btn" class="fa-solid fa-user"></div></a>
   </div>

   <nav class="navbar">
      <a href="index.php#home">acasă</a>
      <a href="index.php#about">despre</a>
      <a href="index.php#reservation">rezervări</a>
      <a href="index.php#gallery">galerie</a>
      <a href="index.php#contact">contact</a>
      <a href="index.php#reviews">review-uri</a>
      <a href="bookings.php">rezervările mele</a>
      
   </nav>

</section>

