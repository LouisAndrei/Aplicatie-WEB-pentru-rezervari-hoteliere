// Selectează profilul
let profile = document.querySelector('.header .flex .profile');

// Atașează un eveniment onclick butonului utilizatorului
document.querySelector('#user-btn').onclick = () =>{
   // Adaugă sau elimină clasa 'active' de pe profil
   profile.classList.toggle('active');
}

// Atașează un eveniment la scroll-ul ferestrei
window.onscroll = () =>{
   // Elimină clasa 'active' de pe profil
   profile.classList.remove('active');
}

// Selectează toate elementele de tip input cu atributul 'type' setat la 'number'
document.querySelectorAll('input[type="number"]').forEach(inputNumber => {
   // Atașează un eveniment oninput la fiecare element selectat
   inputNumber.oninput = () =>{
      // Verifică dacă lungimea valorii inputului este mai mare decât lungimea maximă permisă
      if(inputNumber.value.length > inputNumber.maxLength)
         // Taie valoarea inputului la lungimea maximă permisă
         inputNumber.value = inputNumber.value.slice(0, inputNumber.maxLength);
   };
});
