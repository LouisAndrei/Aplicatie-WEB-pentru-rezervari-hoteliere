<?php

// Includem fișierul de conectare la baza de date
include '../components/connect.php';

// Verificăm dacă există cookie-ul 'admin_id'
if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   $admin_id = '';
   header('location:login.php');
}

// Verificăm dacă s-a trimis formularul de înregistrare
if(isset($_POST['submit'])){

   // Generăm un ID unic pentru admin
   $id = create_unique_id();

   // Preluăm și filtrăm datele din formular
   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING); 
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING); 
   $c_pass = sha1($_POST['c_pass']);
   $c_pass = filter_var($c_pass, FILTER_SANITIZE_STRING);   

   // Verificăm dacă numele de utilizator există deja în baza de date
   $select_admins = $conn->prepare("SELECT * FROM `admins` WHERE name = ?");
   $select_admins->execute([$name]);

   if($select_admins->rowCount() > 0){
      $warning_msg[] = 'Username already taken!';
   }else{
      // Verificăm dacă parolele coincid
      if($pass != $c_pass){
         $warning_msg[] = 'Password not matched!';
      }else{
         // Înserăm adminul în baza de date
         $insert_admin = $conn->prepare("INSERT INTO `admins`(id, name, password) VALUES(?,?,?)");
         $insert_admin->execute([$id, $name, $c_pass]);
         $success_msg[] = 'Registered successfully!';
      }
   }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>
   
<!-- header  -->
<?php include '../components/admin_header.php'; ?>
<!-- header  -->

<!-- inceputul sectiunii register   -->

<section class="form-container">

   <form action="" method="POST">
      <h3>register</h3>
      <input type="text" name="name" placeholder="introdu numele de utilizator" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="pass" placeholder="introdu parola" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="password" name="c_pass" placeholder="confirma parola" maxlength="20" class="box" required oninput="this.value = this.value.replace(/\s/g, '')">
      <input type="submit" value="register" name="submit" class="btn">
   </form>

</section>

<!-- sfarsitul sectiunii register  -->





<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!--  js file link  -->
<script src="../js/admin_script.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html>