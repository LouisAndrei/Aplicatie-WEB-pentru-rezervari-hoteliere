<?php

// Includem fișierul de conectare la baza de date
include '../components/connect.php';

// Verificăm dacă există o valoare pentru cookie-ul 'admin_id'
if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   $admin_id = '';
   // Redirecționăm către pagina de login în cazul în care cookie-ul 'admin_id' lipsește
   header('location:login.php');
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>
   
<!-- header   -->
<?php include '../components/admin_header.php'; ?>
<!-- header  -->

<!-- inceputul sectiunii dashboard   -->

<section class="dashboard">

   <h1 class="heading">panou de administrare</h1>

   <div class="box-container">

   <div class="box">
   <?php
         // Selectăm profilul adminului cu id-ul specificat
         $select_profile = $conn->prepare("SELECT * FROM `admins` WHERE id = ? LIMIT 1");
         $select_profile->execute([$admin_id]);
         // Extragem profilul adminului din rezultatul interogării
         $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
      ?>

      <h3>salut!</h3>
      <p><?= $fetch_profile['name']; ?></p>
      <a href="update.php" class="btn">actualizeaza profil</a>
   </div>

   <div class="box">
   <?php
         // Selectăm toate rezervările din tabelul 'bookings'
         $select_bookings = $conn->prepare("SELECT * FROM `bookings`");
         $select_bookings->execute();
         // Numărăm rezervările din rezultatul interogării
         $count_bookings = $select_bookings->rowCount();
      ?>

      <h3><?= $count_bookings; ?></h3>
      <p>rezervari</p>
      <a href="bookings.php" class="btn">vezi rezervarile</a>
   </div>

   <div class="box">
   <?php
         // Selectăm toți adminii din tabelul 'admins'
         $select_admins = $conn->prepare("SELECT * FROM `admins`");
         $select_admins->execute();
         // Numărăm adminii din rezultatul interogării
         $count_admins = $select_admins->rowCount();
      ?>

      <h3><?= $count_admins; ?></h3>
      <p>admini</p>
      <a href="admins.php" class="btn">vezi adminii</a>
   </div>

   <div class="box">
   <?php
         // Selectăm toate mesajele din tabelul 'messages'
         $select_messages = $conn->prepare("SELECT * FROM `messages`");
         $select_messages->execute();
         // Numărăm mesajele din rezultatul interogării
         $count_messages = $select_messages->rowCount();
      ?>

      <h3><?= $count_messages; ?></h3>
      <p>mesaje</p>
      <a href="messages.php" class="btn">vezi mesaje</a>
   </div>

   <div class="box">
      <h3>login/register</h3>
      <p>login/register</p>
      <a href="login.php" class="btn" style="margin-right: 1rem;">login</a>
      <a href="register.php" class="btn" style="margin-left: 1rem;">register</a>
   </div>

   </div>

</section>


<!-- sfarsitul sectiunii dashboard  -->





<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- js file link  -->
<script src="../js/admin_script.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html>