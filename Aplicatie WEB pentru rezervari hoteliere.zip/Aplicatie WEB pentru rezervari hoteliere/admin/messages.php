<?php

// Includem fișierul de conectare la baza de date
include '../components/connect.php';

// Verificăm dacă există un cookie cu ID-ul adminului autentificat
if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   // Dacă nu există un cookie, setăm valoarea ID-ului adminului la gol și redirecționăm către pagina de autentificare
   $admin_id = '';
   header('location:login.php');
}

// Verificăm dacă s-a efectuat o trimitere a formularului pentru ștergere
if(isset($_POST['delete'])){

   // Preluăm ID-ul mesajului pentru ștergere și îl filtrăm pentru a evita injectările SQL
   $delete_id = $_POST['delete_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   // Verificăm dacă mesajul cu ID-ul specificat există în baza de date
   $verify_delete = $conn->prepare("SELECT * FROM `messages` WHERE id = ?");
   $verify_delete->execute([$delete_id]);

   if($verify_delete->rowCount() > 0){
      // Dacă există, efectuăm ștergerea mesajului
      $delete_messages = $conn->prepare("DELETE FROM `messages` WHERE id = ?");
      $delete_messages->execute([$delete_id]);
      $success_msg[] = 'Message deleted!';
   }else{
      // Dacă mesajul nu există, afișăm un mesaj de avertizare
      $warning_msg[] = 'Message deleted already!';
   }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Mesaje</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>
   
<!-- header   -->
<?php include '../components/admin_header.php'; ?>
<!-- header  -->

<!-- inceputul sectiunii messages   -->

<section class="grid">

   <h1 class="heading">mesaje</h1>

   <div class="box-container">

   <?php
      // Selecționăm toate mesajele din tabela `messages`
      $select_messages = $conn->prepare("SELECT * FROM `messages`");
      $select_messages->execute();
      if($select_messages->rowCount() > 0){
         // Parcurgem rezultatele și preluăm fiecare mesaj în parte
         while($fetch_messages = $select_messages->fetch(PDO::FETCH_ASSOC)){
   ?>

   <div class="box">
      <p>nume : <span><?= $fetch_messages['name']; ?></span></p>
      <p>email : <span><?= $fetch_messages['email']; ?></span></p>
      <p>telefon : <span><?= $fetch_messages['number']; ?></span></p>
      <p>mesaj : <span><?= $fetch_messages['message']; ?></span></p>
      <form action="" method="POST">
         <input type="hidden" name="delete_id" value="<?= $fetch_messages['id']; ?>">
         <input type="submit" value="delete message" onclick="return confirm('delete this message?');" name="delete" class="btn">
      </form>
   </div>
   <?php
      }
   }else{
   ?>
   <div class="box" style="text-align: center;">
      <p>nu a fost gasit niciun mesaj!</p>
      <a href="dashboard.php" class="btn"> inapoi la pagina admin</a>
   </div>
   <?php
      }
   ?>

   </div>

</section>

<!-- sfarsitul sectiunii messages  -->




<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!--  js file link  -->
<script src="../js/admin_script.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html>