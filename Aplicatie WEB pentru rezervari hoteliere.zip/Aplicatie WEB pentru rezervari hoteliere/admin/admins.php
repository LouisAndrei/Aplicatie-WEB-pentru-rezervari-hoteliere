<?php

// Includem fișierul de conectare la baza de date
include '../components/connect.php';

// Verificăm dacă există o valoare pentru cookie-ul 'admin_id'
if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   $admin_id = '';
   // Redirecționăm către pagina de login în cazul în care cookie-ul 'admin_id' lipsește
   header('location:login.php');
}

// Verificăm dacă s-a trimis formularul de ștergere
if(isset($_POST['delete'])){

   $delete_id = $_POST['delete_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   // Verificăm dacă există un admin cu id-ul specificat pentru ștergere
   $verify_delete = $conn->prepare("SELECT * FROM `admins` WHERE id = ?");
   $verify_delete->execute([$delete_id]);

   if($verify_delete->rowCount() > 0){
      // Executăm ștergerea adminului din baza de date
      $delete_admin = $conn->prepare("DELETE FROM `admins` WHERE id = ?");
      $delete_admin->execute([$delete_id]);
      $success_msg[] = 'Admin deleted!';
   }else{
      $warning_msg[] = 'Admin deleted already!';
   }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admins</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!--  css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>
   
<!-- inceputul sectiunii header   -->
<?php include '../components/admin_header.php'; ?>
<!-- sfarsitul sectiunii header  -->

<!-- inceputul sectiunii admins   -->

<section class="grid">

   <h1 class="heading">admini</h1>

   <div class="box-container">

   <div class="box" style="text-align: center;">
      <p>inregistreaza un nou admin</p>
      <a href="register.php" class="btn">register</a>
   </div>

   <?php
      // Selectăm toți adminii din tabelul 'admins'
      $select_admins = $conn->prepare("SELECT * FROM `admins`");
      $select_admins->execute();
      // Verificăm dacă există admini în rezultatul interogării
      if($select_admins->rowCount() > 0){
         // Parcurgem rezultatul și extragem fiecare admin
         while($fetch_admins = $select_admins->fetch(PDO::FETCH_ASSOC)){
   ?>

   <div class="box" <?php if( $fetch_admins['name'] == 'admin'){ echo 'style="display:none;"'; } ?>>
      <p>name : <span><?= $fetch_admins['name']; ?></span></p>
      <form action="" method="POST">
         <input type="hidden" name="delete_id" value="<?= $fetch_admins['id']; ?>">
         <input type="submit" value="delete admins" onclick="return confirm('delete this admin?');" name="delete" class="btn">
      </form>
   </div>
   <?php
      }
   }else{
   }
   ?>

   </div>

</section>

<!-- sfarsitul sectiunii admins  -->




<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- js file link  -->
<script src="../js/admin_script.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html>