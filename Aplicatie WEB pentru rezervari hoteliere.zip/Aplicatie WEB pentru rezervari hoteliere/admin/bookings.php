<?php

// Includem fișierul de conectare la baza de date
include '../components/connect.php';

// Verificăm dacă există o valoare pentru cookie-ul 'admin_id'
if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   $admin_id = '';
   // Redirecționăm către pagina de login în cazul în care cookie-ul 'admin_id' lipsește
   header('location:login.php');
}

// Verificăm dacă s-a trimis formularul de ștergere
if(isset($_POST['delete'])){

   $delete_id = $_POST['delete_id'];
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);

   // Verificăm dacă există o rezervare cu id-ul specificat pentru ștergere
   $verify_delete = $conn->prepare("SELECT * FROM `bookings` WHERE booking_id = ?");
   $verify_delete->execute([$delete_id]);

   if($verify_delete->rowCount() > 0){
      // Executăm ștergerea rezervării din baza de date
      $delete_bookings = $conn->prepare("DELETE FROM `bookings` WHERE booking_id = ?");
      $delete_bookings->execute([$delete_id]);
      $success_msg[] = 'Booking deleted!';
   }else{
      $warning_msg[] = 'Booking deleted already!';
   }

}

// Verificăm dacă s-a trimis formularul de confirmare a rezervării
if(isset($_POST['confirm'])){

   $confirm_id = $_POST['confirm_id'];
   $confirm_id = filter_var($confirm_id, FILTER_SANITIZE_STRING);

   // Verificăm dacă există o rezervare cu id-ul specificat pentru confirmare
   $verify_confirm = $conn->prepare("SELECT * FROM `bookings` WHERE booking_id = ?");
   $verify_confirm->execute([$confirm_id]);

   if($verify_confirm->rowCount() > 0){
      // Executăm actualizarea rezervării în baza de date pentru a o confirma
      $confirm_booking = $conn->prepare("UPDATE `bookings` SET confirmed = 1 WHERE booking_id = ?");
      $confirm_booking->execute([$confirm_id]);
      $success_msg[] = 'Rezervare confirmata!';
   }else{
      $warning_msg[] = 'Nu a fost gasita rezervarea!';
   }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Rezervari</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- css file link  -->
   <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>
   
<!-- inceputul sectiunii header   -->
<?php include '../components/admin_header.php'; ?>
<!-- sfarsitul sectiunii header  -->

<!-- inceputul sectiunii bookings   -->

<section class="grid">

   <h1 class="heading">Rezervari</h1>

   <div class="box-container">

   <?php
      // Selectăm toate rezervările din tabelul 'bookings'
      $select_bookings = $conn->prepare("SELECT * FROM `bookings`");
      $select_bookings->execute();
      // Verificăm dacă există rezervări în rezultatul interogării
      if($select_bookings->rowCount() > 0){
         // Parcurgem rezultatul și extragem fiecare rezervare
         while($fetch_bookings = $select_bookings->fetch(PDO::FETCH_ASSOC)){
   ?>

   <div class="box">
      <p>id-ul rezervarii : <span><?= $fetch_bookings['booking_id']; ?></span></p>
      <p>nume : <span><?= $fetch_bookings['name']; ?></span></p>
      <p>email : <span><?= $fetch_bookings['email']; ?></span></p>
      <p>telefon : <span><?= $fetch_bookings['number']; ?></span></p>
      <p>check in : <span><?= $fetch_bookings['check_in']; ?></span></p>
      <p>check out : <span><?= $fetch_bookings['check_out']; ?></span></p>
      <p>camera : <span><?= $fetch_bookings['rooms']; ?></span></p>
      <p>adulti : <span><?= $fetch_bookings['adults']; ?></span></p>
      <p>copii : <span><?= $fetch_bookings['childs']; ?></span></p>
      <form action="" method="POST">
         <input type="hidden" name="delete_id" value="<?= $fetch_bookings['booking_id']; ?>">
         <input type="submit" value="Sterge rezervare" onclick="return confirm('Stergi aceasta rezervare?');" name="delete" class="btn">
      </form>
      <form action="" method="POST">
         <input type="hidden" name="confirm_id" value="<?= $fetch_bookings['booking_id']; ?>">
         <input type="submit" value="Confirma Rezervarea" onclick="return confirm('Confirmi aceasta rezervare?');" name="confirm" class="btn">
      </form>
   </div>
   <?php
      }
   }else{
   ?>
   <div class="box" style="text-align: center;">
      <p>nu a fost gasita nicio rezervare!</p>
      <a href="dashboard.php" class="btn">pagina admin</a>
   </div>
   <?php
      }
   ?>

   </div>

</section>

<!-- sfarsitul sectiunii bookings  -->




<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- js file link  -->
<script src="../js/admin_script.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html>
