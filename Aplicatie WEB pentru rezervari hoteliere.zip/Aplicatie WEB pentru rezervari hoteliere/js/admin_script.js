// Selectează bara de navigație și butonul meniului
let navbar = document.querySelector('.header .flex .navbar');
let menuBtn = document.querySelector('.header .flex #menu-btn');

// Atașează un eveniment onclick butonului meniului
menuBtn.onclick = () =>{
   // Adaugă sau elimină clasa 'fa-times' de pe butonul meniului
   menuBtn.classList.toggle('fa-times');
   // Adaugă sau elimină clasa 'active' de pe bara de navigație
   navbar.classList.toggle('active');
}

// Atașează un eveniment la scroll-ul ferestrei
window.onscroll = () =>{
   // Elimină clasa 'fa-times' de pe butonul meniului
   menuBtn.classList.remove('fa-times');
   // Elimină clasa 'active' de pe bara de navigație
   navbar.classList.remove('active');
}

// Selectează toate elementele de tip input cu atributul 'type' setat la 'number'
document.querySelectorAll('input[type="number"]').forEach(inputNumbmer => {
   // Atașează un eveniment oninput la fiecare element selectat
   inputNumbmer.oninput = () =>{
      // Verifică dacă lungimea valorii inputului este mai mare decât lungimea maximă permisă
      if(inputNumbmer.value.length > inputNumbmer.maxLength)
         // Taie valoarea inputului la lungimea maximă permisă
         inputNumbmer.value = inputNumbmer.value.slice(0, inputNumbmer.maxLength);
   }
});
