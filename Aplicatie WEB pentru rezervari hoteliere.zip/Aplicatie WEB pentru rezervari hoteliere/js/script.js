// Selectează bara de navigație
let navbar = document.querySelector('.header .navbar');

// Atașează un eveniment onclick butonului meniului
document.querySelector('#menu-btn').onclick = () =>{
   // Adaugă sau elimină clasa 'active' de pe bara de navigație
   navbar.classList.toggle('active');
}

// Atașează un eveniment la scroll-ul ferestrei
window.onscroll = () =>{
   // Elimină clasa 'active' de pe bara de navigație
   navbar.classList.remove('active');
}

// Selectează toate elementele h3 din interiorul elementelor cu clasele '.contact', '.row', '.faq' și '.box'
document.querySelectorAll('.contact .row .faq .box h3').forEach(faqBox => {
   // Atașează un eveniment onclick la fiecare element selectat
   faqBox.onclick = () =>{
      // Adaugă sau elimină clasa 'active' de pe elementul părinte al elementului h3
      faqBox.parentElement.classList.toggle('active');
   }
});

// Selectează toate elementele de tip input cu atributul 'type' setat la 'number'
document.querySelectorAll('input[type="number"]').forEach(inputNumbmer => {
   // Atașează un eveniment oninput la fiecare element selectat
   inputNumbmer.oninput = () =>{
      // Verifică dacă lungimea valorii inputului este mai mare decât lungimea maximă permisă
      if(inputNumbmer.value.length > inputNumbmer.maxLength)
         // Taie valoarea inputului la lungimea maximă permisă
         inputNumbmer.value = inputNumbmer.value.slice(0, inputNumbmer.maxLength);
   }
});

// Inițializează un swiper pentru sliderul cu clasa 'home-slider'
var swiper = new Swiper(".home-slider", {
   loop:true,
   effect: "coverflow",
   spaceBetween: 30,
   grabCursor: true,
   coverflowEffect: {
      rotate: 50,
      stretch: 0,
      depth: 100,
      modifier: 1,
      slideShadows: false,
   },
   navigation: {
     nextEl: ".swiper-button-next",
     prevEl: ".swiper-button-prev",
   },
});

// Inițializează un swiper pentru sliderul cu clasa 'gallery-slider'
var swiper = new Swiper(".gallery-slider", {
   loop:true,
   effect: "coverflow",
   slidesPerView: "auto",
   centeredSlides: true,
   grabCursor: true,
   coverflowEffect: {
      rotate: 0,
      stretch: 0,
      depth: 100,
      modifier: 2,
      slideShadows: true,
   },
   pagination: {
      el: ".swiper-pagination",
   },
});

// Inițializează un swiper pentru sliderul cu clasa 'reviews-slider'
var swiper = new Swiper(".reviews-slider", {
   loop:true,
   slidesPerView: "auto",
   grabCursor: true,
   spaceBetween: 30,
   pagination: {
      el: ".swiper-pagination",
   },
   breakpoints: {
      768: {
        slidesPerView: 1,
      },
      991: {
        slidesPerView: 2,
      },
   },
});
